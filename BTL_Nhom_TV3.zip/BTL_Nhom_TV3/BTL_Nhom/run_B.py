"""run_B.py - [TV3] Thi nghiem B: anh huong cua do rong (so no-ron tang an B).

Bien doc lap : B = 1, 2, ..., 10 va mo rong 16, 32, 64 (de thay ro overfitting).
Kien truc    : MLP 1 tang an, hidden_sizes = [B].
Giu nguyen   : BASELINE (tanh, Adam, lr=1e-2, batch 32, ...), train = 2000 mau,
               tap validation (400) va test (100) co dinh.
Lap lai      : 3 seed (0, 1, 2) -> bao cao trung binh +- do lech chuan.
Chon mo hinh : theo VALIDATION. Test chi danh gia cuoi, khong dung chon B.

Chay (tu thu muc goc):
    python run_B.py              # luu hinh + hien cua so
    python run_B.py --no-show    # chi luu hinh
Dau ra:
    results/B_runs.csv      moi dong = 1 lan chay (B, seed)
    results/B_summary.csv   trung binh +- std theo B
    figures/figB_error_vs_hidden.png
"""
import sys
from pathlib import Path

import pandas as pd

from data_gaussian import get_data
from evaluate import evaluate_model
from train import train_model

ROOT = Path(__file__).resolve().parent
RESULTS_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"

B_VALUES = list(range(1, 11)) + [16, 32, 64]
SEEDS = [0, 1, 2]
N_TRAIN = 2000                                    # dung toan bo train pool
SHOW_FIGURES = "--no-show" not in sys.argv


def run_experiment():
    d = get_data(n_train=N_TRAIN, as_torch=True)  # du lieu co dinh cho moi B
    rows = []
    for B in B_VALUES:
        for seed in SEEDS:
            model, hist, t = train_model(
                d["X_train"], d["y_train"], d["X_val"], d["y_val"],
                hidden_sizes=[B], seed=seed,
                log_csv=RESULTS_DIR / "logs_B" / f"B{B}_seed{seed}.csv")
            m_tr = evaluate_model(model, d["X_train"], d["y_train"])
            m_va = evaluate_model(model, d["X_val"], d["y_val"])
            m_te = evaluate_model(model, d["X_test"], d["y_test"])
            rows.append(dict(
                B=B, seed=seed, n_params=model.n_params(),
                best_epoch=model.best_epoch, epochs_run=len(hist), train_time_s=t,
                **{f"train_{k}": v for k, v in m_tr.items()},
                **{f"val_{k}": v for k, v in m_va.items()},
                **{f"test_{k}": v for k, v in m_te.items()}))
            print(f"B={B:3d} seed={seed}  params={model.n_params():5d}  "
                  f"best_ep={model.best_epoch:3d}  train_MSE={m_tr['mse']:.2e}  "
                  f"val_MSE={m_va['mse']:.2e}  test_MSE={m_te['mse']:.2e}  t={t:.1f}s")
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df["gap_val_minus_train"] = df["val_mse"] - df["train_mse"]   # dau hieu overfitting
    df.to_csv(RESULTS_DIR / "B_runs.csv", index=False)
    return df


def summarize(df):
    cols = ["n_params", "train_mse", "val_mse", "test_mse", "test_mae",
            "test_rmse", "gap_val_minus_train", "best_epoch", "train_time_s"]
    g = df.groupby("B")[cols]
    mean, std = g.mean().add_suffix("_mean"), g.std(ddof=1).add_suffix("_std")
    summ = pd.concat([mean, std], axis=1).reset_index()
    summ.to_csv(RESULTS_DIR / "B_summary.csv", index=False)
    return summ


def plot(summ):
    import matplotlib
    if not SHOW_FIGURES:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = summ["B"]
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.4))
    for key, lab, c in (("train", "Train", "tab:blue"),
                        ("val", "Validation", "tab:orange"),
                        ("test", "Test", "tab:red")):
        axs[0].errorbar(x, summ[f"{key}_mse_mean"], yerr=summ[f"{key}_mse_std"],
                        marker="o", capsize=3, label=lab, color=c)
    axs[0].set_xscale("log", base=2); axs[0].set_yscale("log")
    axs[0].set_xticks(list(x)); axs[0].set_xticklabels([str(int(b)) for b in x])
    axs[0].set_xlabel("Số nơ-ron tầng ẩn B (thang log2)")
    axs[0].set_ylabel("MSE (thang log)")
    axs[0].set_title("(a) MSE theo B (trung bình ± std, 3 seed)")
    axs[0].legend(); axs[0].grid(alpha=0.3, which="both")

    for key, lab, c in (("test_mae", "MAE (test)", "tab:green"),
                        ("test_rmse", "RMSE (test)", "tab:purple")):
        axs[1].errorbar(x, summ[f"{key}_mean"], yerr=summ[f"{key}_std"],
                        marker="s", capsize=3, label=lab, color=c)
    axs[1].set_xscale("log", base=2); axs[1].set_yscale("log")
    axs[1].set_xticks(list(x)); axs[1].set_xticklabels([str(int(b)) for b in x])
    axs[1].set_xlabel("Số nơ-ron tầng ẩn B (thang log2)")
    axs[1].set_ylabel("Sai số (thang log)")
    axs[1].set_title("(b) MAE và RMSE trên tập test")
    axs[1].legend(); axs[1].grid(alpha=0.3, which="both")
    fig.suptitle("Thí nghiệm B: ảnh hưởng của số nơ-ron tầng ẩn (MLP 1 tầng ẩn)")
    fig.tight_layout()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / "figB_error_vs_hidden.png", dpi=200, bbox_inches="tight")
    if SHOW_FIGURES:
        plt.show()
    else:
        plt.close(fig)


def main():
    print(f"Thi nghiem B: B={B_VALUES}, seeds={SEEDS}, n_train={N_TRAIN}")
    df = run_experiment()
    summ = summarize(df)
    print("\n=== TONG HOP B (trung binh qua 3 seed) ===")
    show = summ[["B", "n_params_mean", "train_mse_mean", "val_mse_mean",
                 "test_mse_mean", "test_mae_mean", "gap_val_minus_train_mean"]]
    print(show.to_string(index=False, float_format=lambda v: f"{v:.3e}"))
    best = summ.loc[summ["val_mse_mean"].idxmin()]
    print(f"\nB tot nhat theo VALIDATION: B={int(best['B'])} "
          f"(val_MSE={best['val_mse_mean']:.3e})")
    plot(summ)
    print(f"Da luu: {RESULTS_DIR/'B_runs.csv'}, {RESULTS_DIR/'B_summary.csv'}, "
          f"{FIG_DIR/'figB_error_vs_hidden.png'}")


if __name__ == "__main__":
    main()
