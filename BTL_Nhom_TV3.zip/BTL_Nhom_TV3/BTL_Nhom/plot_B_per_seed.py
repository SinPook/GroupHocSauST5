"""plot_B_per_seed.py - [TV3] Hinh phu cho thi nghiem B: test MSE tung seed theo B.

Doc results/B_runs.csv (do run_B.py sinh ra), ve tung seed + trung binh + trung vi,
va luu bang test MSE theo seed.
Chay (tu thu muc goc, sau khi da chay run_B.py):
    python plot_B_per_seed.py
Dau ra:
    figures/fig11_B_per_seed.png
    results/B_per_seed_test_mse.csv
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent
B = pd.read_csv(ROOT / "results" / "B_runs.csv")

pv = B.pivot(index="B", columns="seed", values="test_mse")
pv.columns = [f"seed{c}" for c in pv.columns]
pv["mean"], pv["median"] = pv.mean(axis=1), pv.median(axis=1)
pv.to_csv(ROOT / "results" / "B_per_seed_test_mse.csv")

fig, ax = plt.subplots(figsize=(7.2, 4.2))
colors = {0: "tab:blue", 1: "tab:orange", 2: "tab:green"}
for s in sorted(B["seed"].unique()):
    d = B[B["seed"] == s].sort_values("B")
    ax.plot(d["B"], d["test_mse"], marker="o", ms=4, lw=1, alpha=0.75,
            color=colors.get(s), label=f"seed {s}")
ax.plot(pv.index, pv["mean"], "k--", lw=2, label="Trung bình")
ax.plot(pv.index, pv["median"], color="tab:red", lw=2, label="Trung vị")
ax.set_xscale("log", base=2)
ax.set_yscale("log")
ticks = sorted(B["B"].unique())
ax.set_xticks(ticks)
ax.set_xticklabels([str(b) for b in ticks])
ax.set_xlabel("Số nơ-ron tầng ẩn B (thang log2)")
ax.set_ylabel("Test MSE (thang log)")
ax.set_title("Test MSE của từng seed theo B")
ax.grid(alpha=0.3, which="both")
ax.legend(ncol=2, fontsize=9)
fig.tight_layout()
(ROOT / "figures").mkdir(exist_ok=True)
fig.savefig(ROOT / "figures" / "fig11_B_per_seed.png", dpi=200)
print("Da luu figures/fig11_B_per_seed.png va results/B_per_seed_test_mse.csv")
