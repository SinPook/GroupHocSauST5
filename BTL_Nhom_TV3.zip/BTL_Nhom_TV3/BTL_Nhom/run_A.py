"""run_A.py - [TV3] Thi nghiem A: anh huong cua so mau train A.

Bien doc lap : A = 200, 400, ..., 2000 (n mau DAU TIEN cua train pool).
Giu nguyen   : BASELINE (MLP 1 tang an 16 no-ron, tanh, Adam, lr=1e-2, ...),
               tap validation (400) va test (100) co dinh.
Lap lai      : 3 seed (0, 1, 2) -> bao cao trung binh +- do lech chuan.
Chon mo hinh : theo VALIDATION (checkpoint/early stopping trong train_model).
Test         : chi danh gia cuoi cho tung lan chay, KHONG dung chon sieu tham so.

Chay (tu thu muc goc):
    python run_A.py              # luu hinh + hien cua so
    python run_A.py --no-show    # chi luu hinh
Dau ra:
    results/A_runs.csv      moi dong = 1 lan chay (A, seed)
    results/A_summary.csv   trung binh +- std theo A
    figures/figA_error_vs_samples.png
"""
import sys
from pathlib import Path

import pandas as pd

from data_gaussian import BASELINE, get_data
from evaluate import evaluate_model
from train import train_model

ROOT = Path(__file__).resolve().parent
RESULTS_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"
CKPT_DIR = ROOT / "checkpoints"

A_VALUES = [200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000]
SEEDS = [0, 1, 2]
HIDDEN_SIZES = list(BASELINE["hidden_sizes"])      # MLP 1 tang an, giu co dinh
SHOW_FIGURES = "--no-show" not in sys.argv


def run_experiment():
    rows = []
    for A in A_VALUES:
        d = get_data(n_train=A, as_torch=True)     # val/test co dinh, train = A mau dau
        for seed in SEEDS:
            model, hist, t = train_model(
                d["X_train"], d["y_train"], d["X_val"], d["y_val"],
                hidden_sizes=HIDDEN_SIZES, seed=seed,
                log_csv=RESULTS_DIR / "logs_A" / f"A{A}_seed{seed}.csv")
            m_tr = evaluate_model(model, d["X_train"], d["y_train"])
            m_va = evaluate_model(model, d["X_val"], d["y_val"])
            m_te = evaluate_model(model, d["X_test"], d["y_test"])
            rows.append(dict(
                A=A, seed=seed, best_epoch=model.best_epoch,
                epochs_run=len(hist), train_time_s=t,
                **{f"train_{k}": v for k, v in m_tr.items()},
                **{f"val_{k}": v for k, v in m_va.items()},
                **{f"test_{k}": v for k, v in m_te.items()}))
            print(f"A={A:5d} seed={seed}  best_ep={model.best_epoch:3d}  "
                  f"train_MSE={m_tr['mse']:.2e}  val_MSE={m_va['mse']:.2e}  "
                  f"test_MSE={m_te['mse']:.2e}  t={t:.1f}s")
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS_DIR / "A_runs.csv", index=False)
    return df


def summarize(df):
    cols = ["train_mse", "val_mse", "test_mse", "test_mae", "test_rmse",
            "best_epoch", "train_time_s"]
    g = df.groupby("A")[cols]
    mean, std = g.mean().add_suffix("_mean"), g.std(ddof=1).add_suffix("_std")
    summ = pd.concat([mean, std], axis=1).reset_index()
    summ.to_csv(RESULTS_DIR / "A_summary.csv", index=False)
    return summ


def plot(summ):
    import matplotlib
    if not SHOW_FIGURES:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axs = plt.subplots(1, 2, figsize=(12, 4.4))
    # (a) MSE train / validation / test
    for key, lab, c in (("train", "Train", "tab:blue"),
                        ("val", "Validation", "tab:orange"),
                        ("test", "Test", "tab:red")):
        axs[0].errorbar(summ["A"], summ[f"{key}_mse_mean"], yerr=summ[f"{key}_mse_std"],
                        marker="o", capsize=3, label=lab, color=c)
    axs[0].set_yscale("log")
    axs[0].set_xlabel("Số mẫu train A"); axs[0].set_ylabel("MSE (thang log)")
    axs[0].set_title("(a) MSE theo A (trung bình ± std, 3 seed)")
    axs[0].legend(); axs[0].grid(alpha=0.3)
    # (b) MAE va RMSE tren test
    for key, lab, c in (("test_mae", "MAE (test)", "tab:green"),
                        ("test_rmse", "RMSE (test)", "tab:purple")):
        axs[1].errorbar(summ["A"], summ[f"{key}_mean"], yerr=summ[f"{key}_std"],
                        marker="s", capsize=3, label=lab, color=c)
    axs[1].set_yscale("log")
    axs[1].set_xlabel("Số mẫu train A"); axs[1].set_ylabel("Sai số (thang log)")
    axs[1].set_title("(b) MAE và RMSE trên tập test")
    axs[1].legend(); axs[1].grid(alpha=0.3)
    fig.suptitle("Thí nghiệm A: ảnh hưởng của số mẫu huấn luyện")
    fig.tight_layout()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / "figA_error_vs_samples.png", dpi=200, bbox_inches="tight")
    if SHOW_FIGURES:
        plt.show()
    else:
        plt.close(fig)


def main():
    print(f"Thi nghiem A: A={A_VALUES}, seeds={SEEDS}, hidden_sizes={HIDDEN_SIZES}")
    df = run_experiment()
    summ = summarize(df)
    print("\n=== TONG HOP A (trung binh qua 3 seed) ===")
    show = summ[["A", "train_mse_mean", "val_mse_mean", "test_mse_mean",
                 "test_mae_mean", "test_rmse_mean", "train_time_s_mean"]]
    print(show.to_string(index=False, float_format=lambda v: f"{v:.3e}"))
    best = summ.loc[summ["val_mse_mean"].idxmin()]
    print(f"\nA tot nhat theo VALIDATION: A={int(best['A'])} "
          f"(val_MSE={best['val_mse_mean']:.3e})")
    plot(summ)
    print(f"Da luu: {RESULTS_DIR/'A_runs.csv'}, {RESULTS_DIR/'A_summary.csv'}, "
          f"{FIG_DIR/'figA_error_vs_samples.png'}")


if __name__ == "__main__":
    main()
