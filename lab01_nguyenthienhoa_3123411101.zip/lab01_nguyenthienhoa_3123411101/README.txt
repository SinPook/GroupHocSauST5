BÀI THỰC HÀNH PYTHON

Họ và tên: Nguyễn Thiện Hòa
MSSV: 3123411101

Các file trong bài:
1. ex4_scientific2.ipynb:
   Vẽ đồ thị hàm số sin(x) và cos(x).

2. calc.py:
   Chứa các hàm cộng, trừ, nhân, chia.

3. main_calc.ipynb:
   Gọi và kiểm tra các hàm trong calc.py.

Môi trường thực hiện:
- Python
- Visual Studio Code
- NumPy
- Matplotlib
- Jupyter Notebook