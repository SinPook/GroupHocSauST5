"""model.py - [TV2] MLP tuy bien bang torch.nn.Module.

Kien truc: Input(2) -> [Linear -> activation] x C -> Linear(out=1)
  - hidden_sizes = [B]      : MLP 1 tang an, B no-ron  (thi nghiem B)
  - hidden_sizes = [B]*C    : C tang an, moi tang B no-ron (thi nghiem C)
Tang ra TUYEN TINH (khong activation) vi day la bai toan hoi quy.
"""
import torch
import torch.nn as nn

ACTIVATIONS = {
    "tanh": nn.Tanh,
    "relu": nn.ReLU,
    "sigmoid": nn.Sigmoid,
    "leaky_relu": nn.LeakyReLU,
    "elu": nn.ELU,
}


class MLP(nn.Module):
    def __init__(self, in_dim=2, hidden_sizes=(16,), out_dim=1, activation="tanh"):
        super().__init__()
        if activation not in ACTIVATIONS:
            raise ValueError(f"activation phai thuoc {list(ACTIVATIONS)}")
        self.in_dim = in_dim
        self.hidden_sizes = list(hidden_sizes)
        self.out_dim = out_dim
        self.activation = activation

        layers, prev = [], in_dim
        for h in self.hidden_sizes:                 # moi tang an: Linear + activation
            layers += [nn.Linear(prev, h), ACTIVATIONS[activation]()]
            prev = h
        layers.append(nn.Linear(prev, out_dim))     # tang ra tuyen tinh
        self.net = nn.Sequential(*layers)
        self._init_weights()

    def _init_weights(self):
        """Xavier cho tanh/sigmoid, Kaiming cho relu; bias = 0."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                if self.activation in ("relu", "leaky_relu", "elu"):
                    nn.init.kaiming_uniform_(m.weight, nonlinearity="relu")
                else:
                    nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        """x: (N, in_dim) -> y_hat: (N, out_dim)."""
        return self.net(x)

    def n_params(self):
        """Tong so tham so hoc duoc (trong so + bias)."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


if __name__ == "__main__":
    for hs in ([1], [16], [16, 16], [16, 16, 16, 16]):
        m = MLP(hidden_sizes=hs)
        out = m(torch.randn(5, 2))
        print(f"hidden_sizes={hs!s:<20} out={tuple(out.shape)}  params={m.n_params()}")
