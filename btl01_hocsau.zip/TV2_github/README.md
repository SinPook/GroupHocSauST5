# BTL01 - Function Approximation

## Cấu trúc
```
BTL01_Nhom_HoTen_MSSV/
├── data_gaussian.py   # [TV1:Nguyễn Lê Tấn Phúc] có sẵn: sinh/chia/kiểm tra/vẽ dữ liệu, get_data(), BASELINE
├── model.py           # [TV2] MLP (nn.Module)           
├── train.py           # [TV2] vòng lặp train/validation 
├── evaluate.py        # [TV2] MSE, MAE/RMSE, hình y–ŷ   
├── run_A.py           # [TV3] thí nghiệm A (số mẫu)     
├── run_B.py           # [TV3] thí nghiệm B (số nơ-ron)  
├── run_C.py           # [TV4] thí nghiệm C (số tầng ẩn) 
├── requirements.txt
├── README.md          # [TV1:Nguyễn Lê Tấn Phúc]
├── data/              # train_pool.csv, val.csv, test.csv 
├── figures/           # hình dữ liệu 
├── results/           # data_statistics.csv (thêm log CSV các thí nghiệm)
├── checkpoints/       # trọng số .pt của mô hình được chọn
├── report/            # BaoCao
└── slides/            # Slide
```
Chạy mọi lệnh từ thư mục gốc, ví dụ `python run_A.py`.

## Cài đặt và chạy phần dữ liệu
```bash
pip install -r requirements.txt     # đã gồm torch (bản CPU là đủ)
python data_gaussian.py             # sinh CSV, kiểm tra, vẽ hình, HIỆN cửa sổ ảnh
python data_gaussian.py --no-show   # chỉ lưu ảnh vào figures/, không hiện cửa sổ
```
Mặc định chương trình vừa lưu ảnh vừa hiện cửa sổ (`SHOW_FIGURES = True` trong file). Đóng các cửa sổ ảnh thì chương trình mới kết thúc. Trên máy không có màn hình, dùng `--no-show`.

## Dữ liệu (cố định cho cả nhóm)
- f(x) = 1/(2π√det C) · exp(−½ (x−μ)ᵀ C⁻¹ (x−μ)), μ = (0, 0), C = [[0.3, −0.5], [−0.5, 2]].
- x₁ ~ U(−2, 2), x₂ ~ U(−4, 4), y = f(x₁, x₂).

| Tập | Số mẫu | Seed | Ghi chú |
|---|---|---|---|
| Train pool | 2000 | 42 | Thí nghiệm A lấy n mẫu **đầu tiên** (tập con lồng nhau) |
| Validation | 400 | 43 | Chọn mô hình, checkpoint, early stopping |
| Test | 100 | 44 | Chỉ đánh giá cuối, không dùng chọn siêu tham số |

Không đổi seed/kích thước tập trong `data_gaussian.py`. Seed của thí nghiệm (`BASELINE["seed"]`) chỉ đổi khởi tạo trọng số và thứ tự shuffle.

## Dùng dữ liệu trong code
```python
from data_gaussian import get_data, BASELINE
d = get_data(n_train=600, as_torch=True)
# d["X_train"], d["y_train"] (N,1), d["X_val"], d["y_val"], d["X_test"], d["y_test"]
```


## Phần mô hình, huấn luyện, đánh giá [TV2]
```bash
python model.py                  # thử các kiến trúc, in số tham số
python train.py                  # huấn luyện baseline 1 seed, in loss, lưu checkpoints/baseline.pt
python evaluate.py --no-show     # baseline 3 seed -> results/baseline_summary.csv, figures/fig5-7
python make_arch_fig.py          # vẽ sơ đồ kiến trúc (figures/fig8_architecture.png)
```
Giao diện cho TV3, TV4 (chạy từ thư mục gốc):
```python
from data_gaussian import get_data, BASELINE
from train import train_model
from evaluate import evaluate_model
d = get_data(n_train=600, as_torch=True)
model, history, t = train_model(d["X_train"], d["y_train"], d["X_val"], d["y_val"],
                                hidden_sizes=[16, 16], cfg={"lr": 1e-2}, seed=0,
                                ckpt_path="checkpoints/x.pt", log_csv="results/x.csv")
m = evaluate_model(model, d["X_test"], d["y_test"])   # {"mse","mae","rmse"}
```
- `cfg` ghi đè `BASELINE` (batch_size, epochs, optimizer, lr, activation, patience).
- Thí nghiệm B: `hidden_sizes=[B]`; thí nghiệm C: `hidden_sizes=[B]*C`.
- Checkpoint và early stopping theo **validation loss**; test chỉ dùng đánh giá cuối.
- `history` là list dict (epoch, train_loss, val_loss); `t` là thời gian train (giây).
