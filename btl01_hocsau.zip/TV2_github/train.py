"""train.py - [TV2] Vong lap huan luyen/validation bang PyTorch.

Giao dien cho TV3, TV4:
    from train import train_model
    model, history, train_time = train_model(
        d["X_train"], d["y_train"], d["X_val"], d["y_val"],
        hidden_sizes=[16], cfg=None, seed=0)
    # history: list[dict] (epoch, train_loss, val_loss); train_time: giay
"""
import copy
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from data_gaussian import BASELINE, get_data
from model import MLP

ROOT = Path(__file__).resolve().parent
CKPT_DIR = ROOT / "checkpoints"
RESULTS_DIR = ROOT / "results"


def set_seed(seed):
    """Co dinh seed de tai lap (khoi tao trong so + thu tu shuffle)."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def make_optimizer(name, params, lr):
    name = name.lower()
    if name == "adam":
        return torch.optim.Adam(params, lr=lr)
    if name == "sgd":
        return torch.optim.SGD(params, lr=lr, momentum=0.9)
    raise ValueError("optimizer phai la 'adam' hoac 'sgd'")


@torch.no_grad()
def eval_loss(model, X, y, criterion):
    """MSE tren mot tap (che do eval, khong tinh gradient)."""
    model.eval()
    return criterion(model(X), y).item()


def train_model(X_train, y_train, X_val, y_val, hidden_sizes=None, cfg=None,
                seed=None, ckpt_path=None, log_csv=None, verbose=False):
    """Huan luyen MLP, chon mo hinh tot nhat theo VALIDATION loss.

    cfg: dict ghi de len BASELINE (batch_size, epochs, optimizer, lr,
         activation, patience). hidden_sizes: list so no-ron moi tang an.
    ckpt_path: neu co, luu checkpoint (.pt) moi khi val loss cai thien.
    log_csv: neu co, ghi loss theo epoch ra CSV.
    Tra ve (model da nap trong so tot nhat, history, thoi gian train giay).
    """
    c = {**BASELINE, **(cfg or {})}
    hidden_sizes = list(c["hidden_sizes"] if hidden_sizes is None else hidden_sizes)
    seed = c["seed"] if seed is None else seed
    set_seed(seed)

    model = MLP(in_dim=X_train.shape[1], hidden_sizes=hidden_sizes,
                out_dim=1, activation=c["activation"])
    criterion = nn.MSELoss()
    optimizer = make_optimizer(c["optimizer"], model.parameters(), c["lr"])

    g = torch.Generator().manual_seed(seed)          # shuffle tai lap duoc
    loader = DataLoader(TensorDataset(X_train, y_train), batch_size=c["batch_size"],
                        shuffle=True, generator=g)

    best_val, best_epoch, best_state, wait = float("inf"), 0, None, 0
    history = []
    t0 = time.perf_counter()
    for epoch in range(1, c["epochs"] + 1):
        # ---- TRAIN: forward -> loss -> zero_grad -> backward -> step ----
        model.train()
        running = 0.0
        for xb, yb in loader:
            pred = model(xb)                         # forward
            loss = criterion(pred, yb)               # MSE
            optimizer.zero_grad()                    # xoa gradient cu
            loss.backward()                          # backpropagation
            optimizer.step()                         # cap nhat tham so
            running += loss.item() * xb.size(0)
        train_loss = running / len(loader.dataset)

        # ---- VALIDATION: eval() + no_grad() ----
        val_loss = eval_loss(model, X_val, y_val, criterion)
        history.append(dict(epoch=epoch, train_loss=train_loss, val_loss=val_loss))

        # ---- Checkpoint tot nhat + early stopping theo val loss ----
        if val_loss < best_val - 1e-12:
            best_val, best_epoch, wait = val_loss, epoch, 0
            best_state = copy.deepcopy(model.state_dict())
            if ckpt_path is not None:
                save_checkpoint(ckpt_path, model, c, best_epoch, best_val)
        else:
            wait += 1
            if wait >= c["patience"]:
                break
        if verbose and (epoch % 20 == 0 or epoch == 1):
            print(f"epoch {epoch:4d}  train={train_loss:.3e}  val={val_loss:.3e}")
    train_time = time.perf_counter() - t0

    model.load_state_dict(best_state)                # nap lai trong so tot nhat
    model.eval()
    model.best_epoch, model.best_val = best_epoch, best_val
    if log_csv is not None:
        Path(log_csv).parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(history).to_csv(log_csv, index=False)
    return model, history, train_time


def save_checkpoint(path, model, cfg, epoch, val_loss):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(dict(state_dict=model.state_dict(), hidden_sizes=model.hidden_sizes,
                    activation=model.activation, cfg=cfg, best_epoch=epoch,
                    best_val_loss=val_loss), path)


def load_checkpoint(path):
    """Nap lai model tu file .pt."""
    ck = torch.load(path, map_location="cpu", weights_only=False)
    model = MLP(hidden_sizes=ck["hidden_sizes"], activation=ck["activation"])
    model.load_state_dict(ck["state_dict"])
    model.eval()
    return model, ck


def main():
    """Chay thu baseline voi 1 seed, in loss va luu log + checkpoint."""
    d = get_data(n_train=2000, as_torch=True)
    model, hist, t = train_model(d["X_train"], d["y_train"], d["X_val"], d["y_val"],
                                 ckpt_path=CKPT_DIR / "baseline.pt",
                                 log_csv=RESULTS_DIR / "baseline_loss_seed0.csv",
                                 verbose=True)
    print(f"\nBest epoch={model.best_epoch}  best val MSE={model.best_val:.3e}  "
          f"time={t:.1f}s  params={model.n_params()}")


if __name__ == "__main__":
    main()
