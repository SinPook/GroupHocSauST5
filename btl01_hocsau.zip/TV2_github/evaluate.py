"""evaluate.py - [TV2] Danh gia mo hinh + truc quan hoa.

Giao dien cho TV3, TV4:
    from evaluate import evaluate_model
    metrics = evaluate_model(model, d["X_test"], d["y_test"])
    # {"mse":..., "mae":..., "rmse":...}   (don vi cua y goc)
TEST chi duoc goi o buoc danh gia cuoi, KHONG dung de chon sieu tham so.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from data_gaussian import BASELINE, X1_RANGE, X2_RANGE, gaussian_2d, get_data
from train import CKPT_DIR, RESULTS_DIR, load_checkpoint, train_model

ROOT = Path(__file__).resolve().parent
FIG_DIR = ROOT / "figures"
SHOW_FIGURES = True
if "--no-show" in sys.argv:
    SHOW_FIGURES = False


@torch.no_grad()
def predict(model, X):
    model.eval()
    return model(X)


def evaluate_model(model, X, y):
    """Tra ve dict MSE, MAE, RMSE (float) tren tap (X, y)."""
    err = predict(model, X) - y
    mse = (err ** 2).mean().item()
    return dict(mse=mse, mae=err.abs().mean().item(), rmse=mse ** 0.5)


def _plt():
    import matplotlib
    if not SHOW_FIGURES:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    return plt


def _finish(fig, plt, path):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / path, dpi=200, bbox_inches="tight")
    if not SHOW_FIGURES:
        plt.close(fig)


def plot_loss_curve(history, path="fig5_loss_curve.png",
                    title="Hình 5. Đường loss theo epoch (baseline)"):
    plt = _plt()
    h = pd.DataFrame(history)
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.plot(h.epoch, h.train_loss, label="Train")
    ax.plot(h.epoch, h.val_loss, label="Validation")
    ax.set_yscale("log"); ax.set_xlabel("Epoch"); ax.set_ylabel("MSE (thang log)")
    ax.set_title(title); ax.legend(); ax.grid(alpha=0.3)
    _finish(fig, plt, path)


def plot_y_vs_yhat(model, X, y, path="fig6_y_vs_yhat.png",
                   title="Hình 6. y thật so với ŷ dự đoán (tập test)"):
    plt = _plt()
    yh = predict(model, X).numpy().ravel(); yt = y.numpy().ravel()
    fig, ax = plt.subplots(figsize=(5.2, 5))
    ax.scatter(yt, yh, s=14, c="tab:red", alpha=0.8, label="Mẫu test")
    lim = [0, max(yt.max(), yh.max()) * 1.05]
    ax.plot(lim, lim, "k--", lw=1, label="ŷ = y (lý tưởng)")
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel("y thật"); ax.set_ylabel("ŷ dự đoán"); ax.set_title(title)
    ax.legend(); ax.grid(alpha=0.3)
    _finish(fig, plt, path)


def plot_surface(model, mean, std, path="fig7_surface_approx.png",
                 title="Hình 7. Bề mặt hàm thật và bề mặt MLP xấp xỉ"):
    """Ve be mat that va be mat MLP tren luoi; mean/std de chuan hoa dau vao."""
    plt = _plt()
    g1, g2 = np.linspace(*X1_RANGE, 80), np.linspace(*X2_RANGE, 80)
    G1, G2 = np.meshgrid(g1, g2)
    grid = np.column_stack([G1.ravel(), G2.ravel()])
    Z = gaussian_2d(grid).reshape(G1.shape)
    Xn = torch.tensor((grid - mean) / std, dtype=torch.float32)
    Zh = predict(model, Xn).numpy().reshape(G1.shape)
    zmax = max(Z.max(), Zh.max())

    fig = plt.figure(figsize=(12, 5))
    for i, (data, name) in enumerate(((Z, "Hàm thật f"), (Zh, "MLP xấp xỉ ŷ")), 1):
        ax = fig.add_subplot(1, 2, i, projection="3d")
        ax.plot_surface(G1, G2, data, cmap="viridis", vmin=0, vmax=zmax,
                        linewidth=0, antialiased=True)
        ax.set_zlim(0, zmax); ax.view_init(28, -60)
        ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); ax.set_zlabel("y")
        ax.set_title(name)
    fig.suptitle(title)
    _finish(fig, plt, path)
    return float(np.abs(Z - Zh).max())


def main():
    """Baseline: 3 seed -> bang MSE/MAE/RMSE (val & test) + hinh cho seed 0."""
    d = get_data(n_train=2000, as_torch=True)
    rows, plt_done = [], False
    for seed in (0, 1, 2):
        ck = CKPT_DIR / f"baseline_seed{seed}.pt"
        model, hist, t = train_model(d["X_train"], d["y_train"], d["X_val"], d["y_val"],
                                     seed=seed, ckpt_path=ck,
                                     log_csv=RESULTS_DIR / f"baseline_loss_seed{seed}.csv")
        m_tr = evaluate_model(model, d["X_train"], d["y_train"])
        m_va = evaluate_model(model, d["X_val"], d["y_val"])
        m_te = evaluate_model(model, d["X_test"], d["y_test"])   # danh gia cuoi
        rows.append(dict(seed=seed, best_epoch=model.best_epoch, train_time_s=t,
                         **{f"train_{k}": v for k, v in m_tr.items()},
                         **{f"val_{k}": v for k, v in m_va.items()},
                         **{f"test_{k}": v for k, v in m_te.items()}))
        print(f"seed {seed}: best_epoch={model.best_epoch:3d}  "
              f"val_MSE={m_va['mse']:.3e}  test_MSE={m_te['mse']:.3e}  "
              f"test_MAE={m_te['mae']:.3e}  test_RMSE={m_te['rmse']:.3e}  t={t:.1f}s")
        if seed == 0:
            plot_loss_curve(hist)
            plot_y_vs_yhat(model, d["X_test"], d["y_test"])
            gap = plot_surface(model, d["mean"], d["std"])
            print(f"  sai lech toi da giua be mat that va MLP: {gap:.4f}")
            _, _ = load_checkpoint(ck)           # kiem tra nap lai checkpoint
            torch.save(model.state_dict(), CKPT_DIR / "best_model_state.pt")
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS_DIR / "baseline_summary.csv", index=False)
    cols = ["train_mse", "val_mse", "test_mse", "test_mae", "test_rmse", "train_time_s"]
    print("\n=== BASELINE (trung binh +- do lech chuan, 3 seed) ===")
    for c in cols:
        print(f"{c:13s} {df[c].mean():.3e} +- {df[c].std(ddof=1):.1e}")
    if SHOW_FIGURES:
        _plt().show()


if __name__ == "__main__":
    main()
